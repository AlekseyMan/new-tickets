<?php $__env->startSection('content'); ?>
    <div class="container-xxl d-flex justify-content-center">
        <a href="/school/create" class="text-decoration-none"><button class="btn btn-primary">Добавить зал</button></a>
    </div>
    <div class="table-responsive">
        <table
            class="table table-vcenter table-striped">
            <thead>
            <tr>
                <th class="col-xl-8 text-center">Выберите клуб</th>
                <?php if(auth()->guard('sanctum')->check()): ?>
                <th class="col-xl-2">Редактировать</th>
                <th class="col-xl-2">Удалить</th>
                <?php endif; ?>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center cursor-pointer"
                        onclick="location.href = '/school/<?php echo e($item->id); ?>'">
                        <h3><?php echo e($item->name . ": " . $item->address); ?></h3>
                    </td>
                    <?php if(auth()->guard('sanctum')->check()): ?>
                    <td class="text-muted">
                        Edit
                    </td>
                    <td class="text-muted">Delete</td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asket/docker/www/new-tickets.site/resources/views/pages/index.blade.php ENDPATH**/ ?>
