<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center">
        <form action="/karateki" method="POST" class="card col-8">
            <?php echo csrf_field(); ?>
            <div class="card-header">
                <h3 class="">Добавить ученика</h3>
            </div>
            <input type="hidden" name="profile_role" value="<?php echo e($role); ?>">
            <div class="card-body">
                <label for="surname"><b>Введите фамилию</b><span class="text-danger"> *</span></label>
                <input type="text" class="form-control mb-3" name="surname" placeholder="Введите фамилию" autocomplete="off" required>

                <label for="name"><b>Введите имя</b><span class="text-danger"> *</span></label>
                <input type="text" class="form-control mb-3" name="name" placeholder="Введите имя" autocomplete="off" required>

                <label class="mt-3" for="coach_id">
                    <b>Выберите тренера</b><span class="text-danger"> *</span>
                </label>
                <select name="coach_id" class="form-select">
                    <?php $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($coach->id); ?>">
                            <?php echo e($coach->surname); ?> <?php echo e($coach->name); ?> <?php echo e($coach->patronymic); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div>
                    <div class="form-select mt-2" onclick="hideShowAdvancedBlock()"><b>Дополнительные параметры</b></div>
                    <div class="form-control d-none" id="advanced-block">
                        <label for="birthday">Дата рождения</label>
                        <input type="date" value="<?php echo e(old('birthday')); ?>" name="birthday" class="form-control mb-2">
                        <label for="weight">Вес</label>
                        <input type="text" value="<?php echo e(old('weight')); ?>" name="weight" class="form-control mb-2" placeholder="000,00">


                        <label for="qu">Кю</label>
                        <select name="qu" id="qu" class="form-select col-2">
                            <option value="">-</option>
                        </select>
                        <label for="dan">Дан</label>
                        <select name="dan" id="dan" class="form-select col-2">
                            <option value="">-</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="btn btn-secondary me-3">
                    <a href="<?php echo e(URL::previous()); ?>" class="text-decoration-none text-white">Отмена</a>
                </div>
                <button class="btn btn-primary me-3">
                    Добавить
                </button>
            </div>
        </form>
    </div>
    <script>
        function hideShowAdvancedBlock(){
            let target = document.getElementById("advanced-block").className
            if(target === "form-control"){
                document.getElementById("advanced-block").className = "form-control d-none"
            } else {
                document.getElementById("advanced-block").className = "form-control"
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asket/docker/www/new-tickets.site/resources/views/pages/karateki/create.blade.php ENDPATH**/ ?>