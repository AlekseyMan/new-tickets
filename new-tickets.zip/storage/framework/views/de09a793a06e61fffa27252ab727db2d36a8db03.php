<?php $__env->startSection('content'); ?>
    <div class="card col-xl-6 m-auto d-flex justify-content-center flex-column align-items-center mt-5 ">
        <h2 class="mt-3">Добавить зал</h2>
        <form <?php if(!isset($school)): ?> method="POST" action="/school" <?php else: ?> method="PATCH" action="/school/<?php echo e($school->id); ?>" <?php endif; ?>
              class="p-2 col-xl-9 text-center">
            <?php echo csrf_field(); ?>
            <label for="name">Название зал <span class="text-danger">*</span></label>
            <div class="text-danger"> <?php echo e($errors->first('name')); ?> </div>
            <input class="form-control m-2" type="text" name="name" id="name" autocomplete="off"
                   <?php if(isset($school)): ?>value="<?php echo e($school->name); ?>" <?php else: ?> value="<?php echo e(old('name')); ?>"<?php endif; ?>>
            <label for="address">Адрес зала <span class="text-danger">*</span></label>
            <div class="text-danger"> <?php echo e($errors->first('address')); ?> </div>
            <input class="form-control m-2" type="text" name="address" id="address" autocomplete="off"
                   <?php if(isset($school)): ?>value="<?php echo e($school->address); ?>"<?php else: ?> value="<?php echo e(old('address')); ?>"<?php endif; ?>>
            <?php if(isset($school)): ?>
                <button class="btn btn-primary m-3">Сохранить</button>
            <?php else: ?>
                <button class="btn btn-success m-3">Добавить</button>
            <?php endif; ?>

            <div>Не обязательные для заполнения поля</div>
            <label for="description">Описание клуба</label>
            <div class="text-danger"> <?php echo e($errors->first("description")); ?> </div>
            <textarea class="form-control m-2" name="description" id="description" rows="5">
                <?php if(isset($school)): ?><?php echo e($school->description); ?><?php else: ?> <?php echo e(old('description')); ?><?php endif; ?></textarea>
            <label for="contacts['phone']">Контактный телефон</label>
            <div class="text-danger"> <?php echo e($errors->first("contacts['phone']")); ?> </div>
            <input class="form-control m-2" type="tel" name="contacts['phone']" id="contacts['phone']" autocomplete="off"
                   <?php if(isset($school)): ?>value="<?php echo e(json_decode($school->contacts)?->phone); ?>"<?php else: ?> value="<?php echo e(old("contacts['phone']")); ?>"<?php endif; ?>>
            <label for="contacts['coach']">Ответственный за клуб</label>
            <div class="text-danger"> <?php echo e($errors->first("contacts['coach']")); ?> </div>
            <select name="contacts['coach']" id="contacts['coach']" class="form-control form-select m-2">
                <option value="">-</option>
                <?php if(isset($coaches)): ?>
                    <?php $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($coach->id); ?>" <?php if(isset($school) AND json_decode($school->contacts)?->coach == $coach->id): ?> selected <?php endif; ?>><?php echo e($coach->fullName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asket/docker/www/new-tickets.site/resources/views/pages/create.blade.php ENDPATH**/ ?>
