<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-start m-3">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addKaratekaToGroup">
            Добавить спорстменов в группу
        </button>
        <div class="ms-5 d-flex justify-content-between col-xl-7">
            <h4><?php echo e($group->formatedSchedule); ?></h4>
            <h3>Тренер: <?php echo e($group->coach->surname); ?> <?php echo e($group->coach->name); ?> <?php echo e($group->coach->patronymic); ?></h3>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-vcenter" id="token" data-token="<?php echo e(csrf_token()); ?>">
            <thead>
            <tr class="text-center">
                <th class="col-xl-1"></th>
                <th class="col-xl-3">Спортсмен</th>
                <th class="col-xl-2">Посещение</th>
                <th class="col-xl-2">Пропуск</th>
                <th class="col-xl-2">Баланс</th>
                <th class="col-xl-1">Занятия</th>
                <th class="col-xl-2">Окончание</th>
                <th class="col-xl-1"></th>
            </tr>
            </thead>
            <tbody id="tbody">
            <?php $__currentLoopData = $group->karateki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center <?php if((int)$user->balance < 0): ?> bg-danger <?php endif; ?>" id="trUserId=<?php echo e($user->id); ?>">
                    <td>
                        <button type="button" class="btn-danger" data-bs-toggle="modal"
                                data-bs-target="#removeFromGroup"
                                onclick="addDataToModal('<?php echo e($user->id); ?>', 'remove')">X
                        </button>
                    </td>
                    <td class="" id="userNameId=<?php echo e($user->id); ?>">
                        <a href="/karateki/<?php echo e($user->id); ?>" class="text-black text-decoration-none">
                            <?php echo e($user->surname); ?> <?php echo e($user->name); ?>

                        </a>
                    </td>
                    <td>
                        <?php if(isset($user->ticket) AND $user->ticket->paused == 1): ?>
                            Абонемент на паузе
                        <?php else: ?>
                            <button data-ticketid="<?php echo e($user->ticket->id ?? 0); ?>"
                                    class="btn <?php if(isset($user->ticket->visit)): ?> btn-success <?php endif; ?>"
                                    onclick="markVisit('visit-<?php echo e($user->id); ?>-<?php echo e($user->ticket->id ?? 0); ?>')"
                                    id="visit-<?php echo e($user->id); ?>-<?php echo e($user->ticket->id ?? 0); ?>">
                                Посетил
                            </button>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(isset($user->ticket) AND $user->ticket->paused == 1): ?>
                            Абонемент на паузе
                        <?php else: ?>
                            <button data-ticketid="<?php echo e($user->ticket->id ?? 0); ?>"
                                    class="btn <?php if(isset($user->ticket->miss)): ?> btn-danger <?php endif; ?>"
                                    onclick="markVisit('miss-<?php echo e($user->id); ?>-<?php echo e($user->ticket->id ?? 0); ?>')"
                                    id="miss-<?php echo e($user->id); ?>-<?php echo e($user->ticket->id ?? 0); ?>">
                                Пропустил
                            </button>
                        <?php endif; ?>
                    </td>
                    <td class=""
                        id="userBalanceId=<?php echo e($user->id); ?>">
                        <b id="userId=<?php echo e($user->id); ?>"><?php echo e($user->balance ?? 0); ?></b>
                        <button type="button" class="btn btn-light ms-2" data-bs-toggle="modal"
                                data-bs-target="#addBalance"
                                onclick="addDataToModal('<?php echo e($user->id); ?>', 'balance')">+
                        </button>
                    </td>
                    <td id="count-<?php echo e($user->id); ?>-<?php echo e($user->ticket->id ?? 0); ?>"><?php echo e($user->ticket?->visitsNumber ?? 0); ?></td>
                    <td class="text-center" id="ticketDateid=<?php echo e($user->id); ?>">
                        <?php if(isset($user->ticket->is_closed) AND $user->ticket->is_closed == 0): ?>
                            <?php echo e($user->ticket?->end_date); ?>

                        <?php else: ?>
                            Нет абонемента
                        <?php endif; ?>
                    </td>
                    <td><?php if(isset($user->ticket->is_closed) AND $user->ticket->is_closed == 0): ?>
                        <?php else: ?>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAbonement"
                                    id="button-<?php echo e($user->id); ?>-<?php echo e($user->ticket->id ?? 0); ?>"
                                    onclick="addDataToModal('<?php echo e($user->id); ?>', 'abonement')">+
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php if (isset($component)) { $__componentOriginal48f14bc497a540149539d246ba90c903cc0ef61a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AddAbonementModal::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('add-abonement-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AddAbonementModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal48f14bc497a540149539d246ba90c903cc0ef61a)): ?>
<?php $component = $__componentOriginal48f14bc497a540149539d246ba90c903cc0ef61a; ?>
<?php unset($__componentOriginal48f14bc497a540149539d246ba90c903cc0ef61a); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.add-balance-modal','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('add-balance-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalafddafeeacfeffdad786e5013f08ee623736bc3a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\RemoveFromGroupModal::class, ['groupId' => ''.e($group->id).''] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('remove-from-group-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\RemoveFromGroupModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalafddafeeacfeffdad786e5013f08ee623736bc3a)): ?>
<?php $component = $__componentOriginalafddafeeacfeffdad786e5013f08ee623736bc3a; ?>
<?php unset($__componentOriginalafddafeeacfeffdad786e5013f08ee623736bc3a); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal0580a4ad9d3823d9098547182a980ef83703fcc1 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AddKaratekaToGroupModal::class, ['groupId' => ''.e($group->id).''] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('add-karateka-to-group-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AddKaratekaToGroupModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0580a4ad9d3823d9098547182a980ef83703fcc1)): ?>
<?php $component = $__componentOriginal0580a4ad9d3823d9098547182a980ef83703fcc1; ?>
<?php unset($__componentOriginal0580a4ad9d3823d9098547182a980ef83703fcc1); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asket/docker/www/new-tickets.site/resources/views/pages/group/show.blade.php ENDPATH**/ ?>