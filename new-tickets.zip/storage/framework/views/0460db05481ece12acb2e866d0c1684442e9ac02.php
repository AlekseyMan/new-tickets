<div class="modal fade" id="addAbonement" tabindex="-1" aria-labelledby="addAbonementLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form class="modal-content" method="POST" id="add-abonement">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="balance" value="<?php echo e(-$abonementCost); ?>">
            <div class="modal-header">
                <h5 class="modal-title" id="addAbonementLabel"  data-userid=""></h5>
            </div>
            <div class="modal-body">
                С баланса пользователя будет списано <?php echo e($abonementCost); ?>. Открываем?
            </div>
            <div class="modal-footer">
                <div class="btn btn-secondary" data-bs-dismiss="modal">Отмена</div>
                <button class="btn btn-primary" data-bs-dismiss="modal">Да, открываем</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH /home/asket/docker/www/new-tickets.site/resources/views/components/add-abonement-modal.blade.php ENDPATH**/ ?>