<div class="modal fade" id="addKaratekaToGroup" tabindex="-1" aria-labelledby="addKaratekaToGroupLabel"
     aria-hidden="true">
    <div class="modal-dialog">
        <form action="/group/<?php echo e($group->id); ?>/add-karateki-to-group" method="POST" class="modal-content">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
                <h5 class="modal-title" id="addKaratekaToGroupLabel">Добавить </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Добавить в группу:
                <select name="ids[]" id="selectKarateka" class="form-select" multiple
                        aria-label="multiple select example">
                    <option disabled selected value="0">Выберите спорстмена</option>
                    <?php $__currentLoopData = $karateki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($show = true); ?>

                        <?php $__currentLoopData = $group->karateki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($groupUser->id === $user->id): ?>
                                <?php echo e($show = false); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($show): ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->surname); ?> <?php echo e($user->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="modal-footer">
                <div class="btn btn-secondary" data-bs-dismiss="modal">Отмена</div>
                <button class="btn btn-primary" data-bs-dismiss="modal">
                    Добавить
                </button>
            </div>
        </form>
    </div>
</div>

<?php /**PATH /home/asket/docker/www/new-tickets.site/resources/views/components/add-karateka-to-group-modal.blade.php ENDPATH**/ ?>