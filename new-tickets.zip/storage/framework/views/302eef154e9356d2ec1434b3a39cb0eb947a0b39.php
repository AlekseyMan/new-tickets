<?php $__env->startSection('content'); ?>
    <div class="col-xl-12 text-center">
        <h3 class=""><?php echo e($school->name); ?></h3>
        <h5><?php echo e($school->address); ?></h5>
    </div>
    <div class="table-responsive">
        <table
            class="table table-vcenter table-striped">
            <thead>
            <tr>
                <th class="col-xl-2">Группа</th>
                <th class="col-xl-2">Расписание</th>
                <th class="col-xl-4">Тренер</th>
                <th class="col-xl-2">Редактировать</th>
                <th class="col-xl-2">Удалить</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $school->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="">
                    <td>
                        <form action="/group/<?php echo e($group->id); ?>">
                            <button class="btn btn-success"><?php echo e($group->name); ?></button>
                        </form>
                    </td>
                    <td>
                        <?php echo e($group->formatedSchedule); ?>

                    </td>
                    <td>
                        <?php if(isset($group->coach)): ?>
                            <?php echo e($group->coach->surname); ?> <?php echo e($group->coach->name); ?> <?php echo e($group->coach->patronymic); ?>

                        <?php endif; ?>
                    </td>
                    <td class="col-xl-2">
                        <form action="/group/<?php echo e($group->id); ?>/edit" method="GET">
                            <button class="btn btn-primary">Редактировать</button>
                        </form>
                    </td>
                    <td class="col-xl-2">
                        <form action="/group/<?php echo e($group->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="DELETE">
                            <button class="btn btn-danger">Удалить</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="card col-xl-6 m-auto d-flex justify-content-center flex-column align-items-center mt-5 ">
        <h4 class="mt-3">Добавить группу</h4>
        <form method="POST" action="/group"
              class="p-2 col-xl-9 text-center">
            <input type="hidden" name="school_id" value="<?php echo e($school->id); ?>">
            <?php echo csrf_field(); ?>
            <label for="name">Название группы</label>
            <input type="text" class="form-control m-2" name="name" value="<?php echo e(old('name')); ?>">
            <p>Выберите время группы</p>
            <div class="d-flex justify-content-center">
                <input class="form-control m-2 w-25" type="time" name="schedule[times][]" required>
                <input class="form-control m-2 w-25" type="time" name="schedule[times][]" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Выберите дни</label>
                <div class="form-selectgroup">
                    <?php $__currentLoopData = $school->days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shortDay => $fullDayName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-selectgroup-item">
                            <input type="checkbox" name="schedule[days][]" value="<?php echo e($shortDay); ?>" class="form-selectgroup-input">
                            <span class="form-selectgroup-label"><?php echo e($shortDay); ?></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <select name="coach_id" class="form-select">
                <?php $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($coach->id); ?>">
                        <?php echo e($coach->surname . ' ' . $coach->name . ' ' . $coach->patronymic); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="btn btn-success mb-4 mt-2">Добавить</button>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asket/docker/www/new-tickets.site/resources/views/pages/school/show.blade.php ENDPATH**/ ?>