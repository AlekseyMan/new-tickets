<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <div class="col-xl-12 d-flex justify-content-center m-3" id="token" data-token="<?php echo e(csrf_token()); ?>">
            <button type="button" class="btn btn-success">
                <a href="/karateki/create" class="text-decoration-none text-white">Добавить спортсмена</a>
            </button>
        </div>
        <table class="table table-vcenter">
            <thead>
            <tr>
                <th class="col-3 text-center">Фамилия Имя</th>
                <th class="col-2 text-center">Дата рождения</th>
                <th class="col-1 text-center">Кю</th>
                <th class="col-1 text-center">Вес</th>
                <th class="col-1">Редактировать</th>
            </tr>
            </thead>
            <tbody id="tbody">
            <?php if(isset($karateki)): ?>
                <?php $__currentLoopData = $karateki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td
                            <?php if(isset($user->ticket)): ?>
                                class="<?php if($user->ticket->paused === 1): ?> bg-blue <?php else: ?> bg-success <?php endif; ?>"
                            <?php endif; ?>
                        >
                            <a href="/karateki/<?php echo e($user->id); ?>" class="text-dark text-decoration-none">
                                <h3><?php echo e($user->surname. " " . $user->name); ?></h3>
                            </a>
                        </td>
                        <td><?php echo e($user->birthday); ?></td>
                        <td><?php echo e($user->qu); ?></td>
                        <td><?php echo e($user->weight); ?></td>
                        <td class="text-muted">
                            <form action="/karateki/<?php echo e($user->id); ?>/edit" method="GET">
                                <button class="btn btn-primary">Редактировать</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asket/docker/www/new-tickets.site/resources/views/pages/karateki/index.blade.php ENDPATH**/ ?>